import { initExpressApp } from './express';

initExpressApp();