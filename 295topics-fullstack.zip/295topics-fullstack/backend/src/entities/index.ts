export interface Topic {
    id?: string;
    Name: string;
}