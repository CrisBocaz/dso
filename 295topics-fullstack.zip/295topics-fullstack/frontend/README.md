# 295topics-frontend

## Probando Local

Esta aplicación requiere conexion con el backend

Ten en cuenta que se requiere la variable `API_URI`

por ejemplo `API_URI: http://topics-api:5000/api/topics`

```bash
npm start
```

probando

```bash
curl http://localhost:3000
```
